<?php

	set_time_limit(0);
	//require the bootstrap include
	define('DRUPAL_ROOT', getcwd());

	require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
	drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
?>
<html>
<style type="text/css" media="all">
	@import url("css/ui-lightness/jquery-ui-1.8.18.custom.css");
	@import url("css/slots.css");
</style>
<script type="text/javascript" src="scripts/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery-ui-1.8.18.custom.min.js"></script>

<body>
<div style="text-align:center;">
  <video id="basic-stream" class="videostream" autoplay></video>
  <p><button id="capture-button">Capture video</button>
  <button id="blur-button">Blur</button> 
  <button id="stop-button">Stop</button></p>
</div>
<script>
function onFailSoHard(e) {
  if (e.code == 1) {
    alert('User denied access to their camera');
  } else {
    alert('getUserMedia() not supported in your browser.');
  }
  //e.target.src = 'http://www.html5rocks.com/en/tutorials/video/basics/Chrome_ImF.ogv';
}

(function() {
var video = document.querySelector('#basic-stream');
var button = document.querySelector('#capture-button');
var localMediaStream = null;

//button.addEventListener('click', function(e) {
  if (navigator.getUserMedia) {
    navigator.getUserMedia('video', function(stream) {
      video.src = stream;
      //video.controls = true;
      localMediaStream = stream;
    }, onFailSoHard);
  } else if (navigator.webkitGetUserMedia) {
    navigator.webkitGetUserMedia({video: true}, function(stream) {
      video.src = window.webkitURL.createObjectURL(stream);
      //video.controls = true;
      localMediaStream = stream;
    }, onFailSoHard);
  } else {
    onFailSoHard({target: video});
  }
//}, false);

document.querySelector('#stop-button').addEventListener('click', function(e) {
  video.pause();
  localMediaStream.stop(); // Doesn't do anything in Chrome.
}, false);
})();




$('#blur-button').click( function() {
		$('#basic-stream').slideToggle(2000);
	for(i=0; i<1; i+= 0.1) {
			//$('#basic-stream').delay(i*3000).css({'-webkit-filter': 'blur(' + (i*i).toString() + 'px)'});	
	//	$('#basic-stream').delay(i*100).css({'-webkit-filter': 'blur(' + (i*.2).toString() + 'px)'}, 5000);
	}
	
});
</script>
