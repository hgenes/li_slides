offset = 0;
cycle = -1;

fname = 'tstream';
rssp = '';

$(function() {
	//alert('ready!');

	updateStream();
	rotateFrame();
	$('.frame').hide();
	$('.activeframe').show();
	//$('.expandframe').imagefit();	
	setInterval( "updateStream()", 15000 );
	setInterval( "rotateFrame()", 15000 );
});

function rotateFrame() {
	if (($('.activeframe').length)) {
		$('.activeframe').each( function() {
			$(this).fadeOut();
			if (($(this).next('.frame')).length) {
				$(this).next('.frame').each( function() {
					$(this).addClass('activeframe');
				});
			} else {
				$('.frame').first().addClass('activeframe');
			}
			$(this).removeClass('activeframe');
			$(this).fadeOut(500);
		});
	} else {
		$('.frame').first().addClass('activeframe').fadeIn(500);
	}
	$('.activeframe').fadeIn(500);
	//$('.expandframe').imagefit();	
}

function updateStream(){
	//alert('update');
	$.ajax({
  	type: 'POST',
    url: 'streams/1/json/interactions?items_per_page=1&offset='+offset,
    data: {'offset':offset,'items_per_page':2},
    success: function(response){
      if(true) {
      	loadFeedback(response);
		  } else {
	      alert(JSON.stringify(response));
	    }
    },
    error: function(request, error){
      alert(error);
      alert("failed");
    }
  });
}

function loadFeedback(response) {
	//response = JSON.parse(response);
	//$('#feedback_0 .inner').html(JSON.stringify(response));
	if ((response.nodes).length) {
		//alert('worked');
		for (node in response.nodes) {

			placeFeedback(response.nodes[node].node['Stream Description']);
			offset += 1;
		}			
	}
	/*if (response.response == 'success') {
		offset = response.offset;
		var feedback = JSON.parse(response.feedback);
		for (item in feedback) {
			(feedback[item])
		}
	}*/
	//$('#feedback').append('<div>OFFSET: ' + offset + '</div>');
}

function placeFeedback(item) {
	$('#feedback_' + cycleBox() + ' .inner').each(function() {
		$(this).fadeOut(200, function() {
			$(this).css('background-color',randomColor(0,0,0,.75,50,50,50,0));
			$(this).html("<div class='feedback'>" + item + '</div>').fadeIn(200);
		});
	});
	
}	

function cycleBox() {
	cycle=cycle+1;
	if (cycle>=maxFeedback) { cycle = 0; }
	return cycle.toString();
}

function randomColor(r, g, b, a, rd, gd, bd, a, ad) {
	var c = 'rgba(' + 
		(r + Math.ceil(Math.random()*rd)). toString() + ', ' +
		(g + Math.ceil(Math.random()*gd)). toString() + ', ' +
		(b + Math.ceil(Math.random()*bd)). toString() + ', .75)';
	return c;
}
