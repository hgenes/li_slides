<?php

	set_time_limit(0);
	//require the bootstrap include
	define('DRUPAL_ROOT', getcwd());

	require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
	drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
?>
<html>
<style type="text/css" media="all">@import url("/css/ui-lightness/jquery-ui-1.8.18.custom.css");@import url("/css/feedback.css");</style>
<script type="text/javascript" src="<?=$base_path?>/scripts/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="<?=$base_path?>/scriptsjquery-ui-1.8.18.custom.min.js"></script>
<script type="text/javascript" src="<?=$base_path?>/scripts/jquery.imagefit-0.2.js"></script>
<script type="text/javascript" src="<?=$base_path?>/scripts/loadlog.js"></script>
<body>

<?
	if(!empty($_REQUEST['nid'])) {
		$stream = node_load($_REQUEST['nid']);
	} else {
		die('Cannot load stream');
	}
	printf ("<div id='#message'><div class='inner'>%s</div></div>",$stream->field_message[$stream->language][0]['safe_value']);
	for($i = 0; $i < $stream->field_simultaneous_interactions[$stream->language][0]['value']; $i++) {
		printf ("<div id='feedback_%s' class='feedback'><div class='inner'></div></div>", $i);
	}
	//print_r($stream);

  $query = db_select('node', 'n');
  $query->fields('n', array('nid'));
  $query->condition('type', 'image_frames', '=');
  $results = $query->execute();   

	$c = 0;
  foreach ($results as $result) {

  	$image = node_load($result->nid);

		foreach($image->field_images[$image->language] as $imagefile) {
  		printf ("<div class='frame expandframe'><img src='%s' class='frameimage' /></div>", file_create_url($imagefile['uri']));
  	}
  	
  }
?>
<script type="text/javascript">
	maxFeedback = <?= $stream->field_simultaneous_interactions[$stream->language][0]['value']?>;
</script>	
