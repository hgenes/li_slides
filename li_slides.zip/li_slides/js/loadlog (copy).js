offset = -1;
cycle = -1;
maxFeedback = 4;
fname = 'tstream';
rssp = '';

$(function() {
	//alert('ready!');

	updateStream();
	$('.frame').hide();
	$('.activeframe').show();
	//$('.expandframe').imagefit();	
	setInterval( "updateStream()", 5000 );
	setInterval( "rotateFrame()", 5000 );
});

function rotateFrame() {
	$('.activeframe').each( function() {
		$(this).fadeOut();
		if (($(this).next('.frame')).length) {
			$(this).next('.frame').each( function() {
				$(this).addClass('activeframe');
			});
		} else {
			$('.frame').first().addClass('activeframe');
		}
		$(this).removeClass('activeframe');
		$(this).fadeOut(500);
	});

	$('.activeframe').fadeIn(500);
	//$('.expandframe').imagefit();	
}

function updateStream(){
	//alert('update');
	$.ajax({
  	type: 'POST',
    url: 'feedbackparse.php',
    data: {'offset':offset,'fname':'tstream'},
    success: function(response){
      if(true) {
      	loadFeedback(response);
		  } else {
	      alert(response);
	    }
    },
    error: function(request, error){
      alert(error);
      alert("failed");
    }
  });
}

function loadFeedback(response) {
	response = JSON.parse(response);
	if (response.response == 'success') {
		offset = response.offset;
		var feedback = JSON.parse(response.feedback);
		for (item in feedback) {
			placeFeedback(feedback[item])
		}
	}
	//$('#feedback').append('<div>OFFSET: ' + offset + '</div>');
}

function placeFeedback(item) {
	$('#feedback_' + cycleBox() + ' .inner').each(function() {
		$(this).fadeOut(200, function() {
			$(this).css('background-color',randomColor(0,0,0,.75,50,50,50,0));
			$(this).html("<div class='feedback'>" + item + '</div>').fadeIn(200);
		});
	});
	
}	

function cycleBox() {
	cycle=cycle+1;
	if (cycle>=maxFeedback) { cycle = 0; }
	return cycle.toString();
}

function randomColor(r, g, b, a, rd, gd, bd, a, ad) {
	var c = 'rgba(' + 
		(r + Math.ceil(Math.random()*rd)). toString() + ', ' +
		(g + Math.ceil(Math.random()*gd)). toString() + ', ' +
		(b + Math.ceil(Math.random()*bd)). toString() + ', .75)';
	return c;
}
