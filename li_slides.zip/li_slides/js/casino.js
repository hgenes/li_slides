state = 'rotating';

setInterval( function() {
	$('.gobutton').fadeIn(300);
	$('.nobutton').fadeOut(700);
	$('#slottitle').css('color', '#ff0');
	$('.slot-images div').css('border-color', '#f00');
	setTimeout( function() {
		$('.gobutton').fadeOut(700);
		$('.nobutton').fadeIn(300);
		$('#slottitle').css('color', '#900');		
		$('.slot-images div').css('border-color', '#ff0');
	}, 550);
}, 1100);

$(function() {
	$('#readytogo').hide();
	$('#intromovie, #waitaminute').hide();
	$('#movie, #slotbody, #slottitle, .slot-images').hide();
	
	function rotateSlotImages() {
		for(i=1; i<=3; i++) {
			//alert('---' +  + '---');
			randomnumber=Math.floor(Math.random()*images.length);
			$('#slot-image-' + i.toString() + ' img').attr('src', images[randomnumber]);
		}
		//$('#slot-image-1 img').width(100);
	}
	
	$('body').keyup( function(e) {
		if((e.which == 39 &&
		  (state=='rotating' ||
		  state=='ready')) ||
		  (e.which == 32 || e.which == 34)) {
			nextState();
			e.preventDefault();
		}
		//alert(e.which);
	}).keydown( function(e) {
		e.preventDefault();
	});
	
	function nextState() {
		if (!animating) {
			switch(state) {
				case 'ready':
					$('#intromovie, #start').fadeOut();
					$('#readytogo').fadeOut(); 
					$('#movie, #slotbody, .slot-images').show();
					rotateInt = setInterval(function(){rotateSlotImages()}, 200);
					setVideoSection(0,3,'slotsmovie');
					// var int=self.setInterval("rotateSlotImages()",1000);
					
					state = 'rotating';
				break;
				case 'rotating':

					nextOutcome();
					state = 'bubbling';
				break;
				case 'bubbling':
					minimizeSlots();
					setVideoSection(9,2,'slotsmovie');
					//setTimeout(function() {wordsFade(currentOutcome.body);}, 2000);

					state = 'wording';
				break;
				case 'wording':
					if(outcomesList.length == 0) {
						//outcomesList = outcomes.slice(0);
						//alert(outcomes.length);
						waitaminute();
					} else {
						//nextOutcome();
						minimizeSlots();
						setVideoSection(15,2,'slotsmovie');
						$('#slotbody, #slottitle').fadeOut();
						setTimeout(function() { 
							$('#intromovie').fadeIn(); 
							setVideoSection(0,6,'intromovie');
							if(outcomesList.length <= 1) {
								$("#readytogo").html("<div id='gobutton' class='gobutton'>LAST CHANCE!</div>").fadeIn();
							}
							setTimeout(function() { 
								//$('#intromovie').fadeOut(); 
								$('#readytogo').fadeIn(3000); 
								}, 3000);
						}, 2000);
					
						state = 'ready';
					}
				break;			
			}
		}
		return 0;
	}
	
	function nextOutcome() {
		clearInterval(rotateInt);

		current=Math.floor(Math.random()*outcomesList.length);
		currentOutcome = JSON.parse(outcomesList.splice(current, 1));
		//alert(outcomesList.splice(current, 1));
		$('#slottitle').html(currentOutcome.title).fadeIn();
		$('#slotbody').html(currentOutcome.body);
		//alert(images[currentOutcome.imagenid[0]]);
		for(i=1; i<=3; i++) {
			$('#slot-image-' + i.toString() + ' img').attr('src', images[imagemap[currentOutcome.imagenid[i-1]]]);
		}
		//$('#slotsmovie').attr('src', 'greenpantslotto.ogv#3,5');
		
		setVideoSection(4,5,'slotsmovie');
		setTimeout(function() {maximizeSlots();}, 3000);
	}
	
	function setVideoSection(start, length, selector) {
		movie = document.getElementById(selector);
		movie.currentTime = start;
		animating = true;
		setTimeout(function() {stopVideo(selector);}, length*1000);
		movie.play();
		
	}
	
	function stopVideo(selector) {
		movie = document.getElementById(selector);	
		movie.pause();
		animating = false;
	}
	
	function maximizeSlots() {
		//a#.find('.slot-image-1 img').animate({width: '300px'}, 2000);
		$('#slot-image-1').animate({left: '10px', top: '10px', 'border-width': '10px'}, 1000).find('img').animate({width: '300px'}, 1000);
		$('#slot-image-2').delay(500).animate({left: '352px', top: '10px', 'border-width': '10px'}, 1000).find('img').delay(500).animate({width: '300px'}, 1000);
		$('#slot-image-3').delay(1000).animate({left: '694px', top: '10px', 'border-width': '10px'}, 1000).find('img').delay(1000).animate({width: '300px'}, 1000);
		//$('.slot-images div').animate({top: '10px', 'border-width': '10px'}, 2000);		
	}

	function minimizeSlots() {
		//alert('dhu');
		$('.slot-images img').animate({width: '100px'}, 1000);
		$('#slot-image-1').animate({left: '335px', top: '160px', 'border-width': '1px'}, 500);
		$('#slot-image-2').animate({left: '437px', top: '160px', 'border-width': '1px'}, 500);
		$('#slot-image-3').animate({left: '539px', top: '160px', 'border-width': '1px'}, 500);						
		//$('.slot-images div').animate({top: '10px', 'border-width': '10px'}, 2000);		
	}

	function wordsFade(text) {
		//$('#slotsbody').html(text);
		//$('#slotbody')
	}
	
	function waitaminute() {
		state = 'waitaminute';
		$('#readytogo').hide();
		$('#intromovie, #waitaminute').hide();
		$('#movie, #slotbody, #slottitle, .slot-images').hide();
		$("#waitaminute").fadeIn();
	}
	
});



