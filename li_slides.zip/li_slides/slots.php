<?php

	set_time_limit(0);
	//require the bootstrap include
	define('DRUPAL_ROOT', getcwd());

	require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
	drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
?>
<html>
<style type="text/css" media="all">@import url("css/ui-lightness/jquery-ui-1.8.18.custom.css");
@import url("css/slots.css");</style>
<script type="text/javascript" src="scripts/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="js/casino.js"></script>
<script type="text/javascript" src="scripts/jquery-ui-1.8.18.custom.min.js"></script>

<body>
<div id='movie'>
    <video id='slotsmovie' src="greenpantslotto.ogv" width='1024'>  
      Your browser does not support the <code>video</code> element.  
    </video>  
</div>

<div id='intro'>
    <video id='intromovie' src="intro.ogv" width='1024'>  
      Your browser does not support the <code>video</code> element.  
    </video>  
</div>

<div class='slot-images'>
	<div id='slot-image-1'><img class='slot-image' width='100'/></div>
	<div id='slot-image-2'><img class='slot-image' width='100'/></div>
	<div id='slot-image-3'><img class='slot-image' width='100'/></div>
</div>
<div id='slottitle'></div>
<div id='slotbody'></div>
<div id='readytogo'><div id='gobutton' class='gobutton'>LET'S GET IN ON IT!</div></div>
<div id='waitaminute'><div class='gobutton'>HOLD UP</div><div class='nobutton'>WAIT A<br/>MINUTE</div></div>
<div id='start'><div class='gobutton'>WE LOVE<br/>DEMOCRACY!</div><div class='nobutton'>TRUST US!</div></div>
<?
	if(!empty($_REQUEST['nid'])) {
		$slot = node_load($_REQUEST['nid']);
	} else {
		die('Cannot load stream');
	}
	
	//print "<pre>"; print_r($slot); die();

  $query = db_select('field_data_field_slot_machine', 'f');
  $query->fields('f', array('entity_id'));
  //$query->entityCondition('entity_type', 'node', '=');
  $query->condition('field_slot_machine_nid', array($slot->nid), '=');
  $results = $query->execute();   

	$outcomes = array();
	$imagenids = array();
	$imagemap = array();
  foreach ($results as $result) {
		$outcome = node_load($result->entity_id);
		if ($outcome->status) {
			$outcomeObject = array();
			$outcomeObject['title'] = $outcome->title;
			$outcomeObject['body'] = $outcome->body['und'][0]['value'];
			foreach($outcome->field_slots_images['und'] as $imagenid) {
				$imagenids[$imagenid['nid']] = $imagenid['nid'];
				$outcomeObject['imagenid'][] = $imagenid['nid'];
			}
			$outcomes[] = '"' . addslashes(json_encode($outcomeObject)). '"';
		}
  }
  $images = node_load_multiple($imagenids);
  $c = 0;
  foreach($images as $nid=>$image) {
  	print (sprintf("<img src='%s' class='imageLoader'/>", file_create_url($image->field_slot_image['und'][0]['uri'])));
  	$imagedivs[$c] = '"' . addslashes(file_create_url($image->field_slot_image['und'][0]['uri'])) . '"';
  	$imagemap[$c] = sprintf("%s: %s", $nid, $c);
  	$c++;
  }
  print sprintf("
  	<script>
  		speed = 100;
  		state = 'wording';
  		animating = false;
			rotateInt = Object; 
			images = new Array(%s);
			imagemap = {%s};			 
			outcomes = new Array(%s); 
			outcomesList = outcomes.slice(0);
			currentOutcome = 0;

		</script>", 
		implode(', ', $imagedivs),
		implode(', ', $imagemap),		
		implode(', ', $outcomes));
  //print implode(', ', $imagedivs);
	//print_r($outcomes);die();  	
?>
