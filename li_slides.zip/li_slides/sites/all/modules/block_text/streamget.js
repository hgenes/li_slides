sizeRatio = 1;
var currentleak = -10;

jQuery(function ($) {

  var current = $.cookie("stream-current");
  var footer = $.cookie("footer-current");

  if (current) {
    dressCurrent(current, "main");
  }
  if (footer) {
    dressCurrent(footer, "footer");
  }
  setInterval(function(){
      current = checkCookie(current, 'stream', 'main');
      footer = checkCookie(footer, 'footer', 'footer');
      flashTitle();
    },1000);

  function checkCookie(active, stream, zone) {
    var changed = $.cookie(stream + "-changed");
    //alert(stream + "-changed" == 'stream-changed');
    if (changed == 1) {
      active = $.cookie(stream + "-current");
      $.cookie(stream + "-changed", 0, { path: '/' });
      dressCurrent(active, zone);
    }
    return active;
  }
  
  function dressCurrent(current, zone) {
    current = $.parseJSON(current);
    $('#' + zone + '-stream-outer').hide();
    $('#' + zone + '-slide-body').text(current.body);
    //$('#' + zone + '-slide-title').text(current.title);
    //setCSS('font-family', current.font_family, '');
    setCSS('font-size', zone, current.title_body_ratio * 1.24, '%');
    setCSS('line-height', zone, current.vertical_spacing, 'em');
    setCSS('letter-spacing', zone, current.horizontal_spacing, 'em', '');
    setCSS('font-variant', zone, current.variant, '');
    setCSS('font-family', zone, current.font_family, '');
    setCSS('top', zone, current.top, 'em', '');
    setCSS('left', zone, current.left, 'em', '');
    $('#' + zone + '-stream-outer').delay(300).show();
    
  }
  
  function setCSS(desc, zone, value, suffix) {
    if (value) {
      $('#' + zone + '-slide-body').css(desc, value.toString() + suffix);
      $('#' + zone + '-slide-title').css(desc, value.toString() + suffix);
    }
  }
  
  function flashTitle() {
    $('.toggle').toggleClass('black');
  }


	
/*Drupal.behaviors.auto_nodetitleFieldsetSummaries = {
  attach: function (context) {
    $('fieldset#edit-auto-nodetitle', context).drupalSetSummary(function (context) {

      // Retrieve the value of the selected radio button
      var ant = $("input[@name=#edit-auto-nodetitle-ant]:checked").val();

      if (ant==0) {
        return Drupal.t('Disabled')
      }
      else if (ant==1) {
        return Drupal.t('Automatic (hide title field)')
      }
      else if (ant==2) {
        return Drupal.t('Automatic (if title empty)')
      }
    });
  }
};*/

});
