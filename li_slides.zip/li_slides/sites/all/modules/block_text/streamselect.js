sizeRatio = 1;

jQuery(function ($) {

  $('.views-field-nothing a').click( function(e) {
    $.cookie("stream-current", $(this).attr('setTo'), { path: '/' });
	  $.cookie("stream-changed", 1, { path: '/' });
	  $('td.views-field-nothing').css('background', 'inherit');
	  $(this).parent().css('background', '#ff0');
	  
	  //alert($.cookie("stream-changed"));
  });
  
  $('.views-field-nothing-1 a').click( function(e) {
    $.cookie("footer-current", $(this).attr('setTo'), { path: '/' });
	  $.cookie("footer-changed", 1, { path: '/' });
	  $('td.views-field-nothing-1').css('background', 'inherit');
	  $(this).parent().css('background', '#0ff');
	  //alert($.cookie("stream-changed"));
  });
/*
  $('.leak-option').hide();
	$('.leak-tag').click( function() {
	  $('.leak-tag').not(this).slideUp();
	  $('.leak-option').not('.' + $(this).attr('tid')).slideUp();
	  $('.' + $(this).attr('tid')).slideDown();
	});
	//$.cookie("test", 1);
	//alert($.cookie("current-leak"));
	$('.leak-option').click( function() {
	  
	  $('.leak-tag').not(this).slideDown();
	  $('.leak-option').slideUp();
	});*/

});
