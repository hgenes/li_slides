sizeRatio = 1;

jQuery(function ($) {

	
	$('#block-text-node-form').before("<div id='block_text_preview'><div class='inner'><div class='text'></div></div></div>");
	sizeRatio = $("#block_text_preview").width() / 1024.0;
	//alert($("#block_text_preview").width());
	$("#block_text_preview").height(720.0*sizeRatio);
	$("#block_text_preview").css('font-size', (100*sizeRatio).toString() + 'px');

	block_text_turn_into_slider("edit-field-title-body-ratio-und-0-value", 50, 300);
	block_text_turn_into_slider("edit-field-vertical-spacing-und-0-value", .6, 2.0, 0.01);
	block_text_turn_into_slider("edit-field-horizontal-spacing-und-0-value", -.4, 2, 0.01);
	block_text_turn_into_slider("edit-field-text-x-offset-und-0-value", 0, 20.0, 0.01);
	block_text_turn_into_slider("edit-field-text-y-offset-und-0-value", 0, 20.0, 0.01);	

	$('#edit-body-und-0-value, #edit-field-title-body-ratio-und-0-value, #edit-field-font-und, #edit-field-variant-und, #edit-field-vertical-spacing-und-0-value, #edit-field-horizontal-spacing-und-0-value, #edit-field-title-body-ratio-und-0-value, #edit-field-text-x-offset-und-0-value, #edit-field-text-y-offset-und-0-value').change( function() {
		block_text_update_preview();
	}).keyup( function() {
		block_text_update_preview();
	});

	function block_text_update_preview() {
		//alert($('#edit-field-horizontal-spacing-und-0-value').val());
		$('#block_text_preview').attr('class',$('#edit-field-variant option:selected').val());
		$('#block_text_preview .inner .text').html($('#edit-body-und-0-value').val().replace(/\n/g,"<br />"));
		$('#block_text_preview .inner').css('font-size', $('#edit-field-title-body-ratio-und-0-value').val() + '%');
		$('#block_text_preview .inner').css('letter-spacing', $('#edit-field-horizontal-spacing-und-0-value').val() + 'em');
		$('#block_text_preview .inner').css('line-height', $('#edit-field-vertical-spacing-und-0-value').val() + 'em');		
		$('#block_text_preview .inner').css('font-family', $('#edit-field-font-und option:selected').val());
		$('#block_text_preview .inner .text').css('padding-left', $('#edit-field-text-x-offset-und-0-value').val() + 'em');	
		$('#block_text_preview .inner .text').css('padding-top', $('#edit-field-text-y-offset-und-0-value').val() + 'em');	


		//functionblock_text_fit_text('#block_text_preview .inner', 256)
	}

	function block_text_turn_into_slider(selector, mini, maxi, steps) {
		if (!steps) {
			steps = 1;
		}
		var $selector_slider = selector + "-slider";
		$('#' + selector).before("<div class='" + $selector_slider + "'></div>");
		$('.' + $selector_slider).slider({
			range: "min",
			value: $('#' + selector).val(),
			min: mini,
			max: maxi,
			step: steps,
			slide: function( event, ui) {
				$('#' + selector).val(ui.value).change();
				//block_text_update_preview();
			}
		});
		$('#' + selector).change( function() {
			$('.' + $selector_slider).val($('#' + selector).val());
		});
		//$(selector).hide();*/
	}
		
	block_text_update_preview();

	symbolsTable = "<table class='symbols'><tr><td>á</td><td>Á</td><td>â</td><td>Â</td><td>´</td><td>æ</td><td>Æ</td><td>à</td><td>À</td><td>ℵ</td><td>α</td><td>Α</td><td>&</td><td>∧</td><td>∠</td><td>'</td><td>Å</td><td>å</td><td>≈</td><td>Ã</td><td>ã</td><td>ä</td><td>Ä</td><td>„</td><td>β</td><td>Β</td><td>¦</td><td>•</td><td>∩</td><td>ç</td><td>Ç</td><td>¸</td><td>¢</td><td>χ</td><td>Χ</td><td>ˆ</td><td>♣</td><td>≅</td><td>©</td><td>↵</td></tr><tr><td>∪</td><td>¤</td><td>‡</td><td>†</td><td>↓</td><td>⇓</td><td>°</td><td>δ</td><td>Δ</td><td>♦</td><td>÷</td><td>É</td><td>é</td><td>Ê</td><td>ê</td><td>È</td><td>è</td><td>∅</td><td>ε</td><td>Ε</td><td>≡</td><td>Η</td><td>η</td><td>Ð</td><td>ð</td><td>Ë</td><td>ë</td><td>€</td><td>∃</td><td>ƒ</td><td>∀</td><td>½</td><td>¼</td><td>¾</td><td>⁄</td><td>Γ</td><td>γ</td><td>≥</td><td>></td><td>↔</td></tr><tr><td>⇔</td><td>♥</td><td>…</td><td>Í</td><td>í</td><td>Î</td><td>î</td><td>¡</td><td>Ì</td><td>ì</td><td>ℑ</td><td>∞</td><td>∫</td><td>Ι</td><td>ι</td><td>¿</td><td>∈</td><td>Ï</td><td>ï</td><td>Κ</td><td>κ</td><td>Λ</td><td>λ</td><td>〈</td><td>«</td><td>←</td><td>⇐</td><td>⌈</td><td>“</td><td>≤</td><td>⌊</td><td>∗</td><td>◊</td><td>‹</td><td>‘</td><td><</td><td>¯</td><td>—</td><td>µ</td><td>·</td></tr><tr><td>Μ</td><td>μ</td><td>∇</td><td>–</td><td>≠</td><td>∋</td><td>¬</td><td>∉</td><td>⊄</td><td>Ñ</td><td>ñ</td><td>Ν</td><td>ν</td><td>Ó</td><td>ó</td><td>Ô</td><td>ô</td><td>Œ</td><td>œ</td><td>ò</td><td>Ò</td><td>‾</td><td>ω</td><td>Ω</td><td>Ο</td><td>ο</td><td>⊕</td><td>∨</td><td>ª</td><td>º</td><td>Ø</td><td>ø</td><td>Õ</td><td>õ</td><td>⊗</td><td>Ö</td><td>ö</td><td>¶</td><td>∂</td><td>‰</td></tr><tr><td>⊥</td><td>Φ</td><td>φ</td><td>Π</td><td>π</td><td>ϖ</td><td>±</td><td>£</td><td>″</td><td>′</td><td>∏</td><td>∝</td><td>ψ</td><td>Ψ</td><td>\"</td><td>√</td><td>〉</td><td>»</td><td>→</td><td>⇒</td><td>⌉</td><td>”</td><td>ℜ</td><td>®</td><td>⌋</td><td>Ρ</td><td>ρ</td><td>›</td><td>’</td><td>Š</td><td>š</td><td>⋅</td><td>§</td><td></td><td>σ</td><td>Σ</td><td>ς</td><td>∼</td><td>♠</td><td>⊂</td><td>⊆</tr><tr><td></td><td>∑</td><td>⊃</td><td>¹</td><td>²</td><td>³</td><td>⊇</td><td>ß</td><td>τ</td><td>Τ</td><td>∴</td><td>Θ</td><td>θ</td><td>ϑ</td><td></td><td>þ</td><td>Þ</td><td>˜</td><td>×</td><td>™</td><td>Ú</td><td>ú</td><td>↑</td><td>⇑</td><td>Û</td><td>û</td><td>ù</td><td>Ù</td><td>¨</td><td>ϒ</td><td>υ</td><td>Υ</td><td>ü</td><td>Ü</td><td>℘</td><td>Ξ</td><td>ξ</td><td>Ý</td><td>ý</td><td>¥</td><td>Ÿ</td></tr><tr><td>ÿ</td><td>ζ</td><td>Ζ</td></tr></table>";
	$('#symbolsClick').after(symbolsTable).click( function(e) {
		$('table.symbols').slideToggle();
		e.preventDefault();
	});
	$('table.symbols').hide();
	$('table.symbols td').click( function() {
		//alert($(this).html());
	}).hover( function() {
		$(this).css({'font-size': '36px'}).css({'padding': '-6px'});
	}, function() {
		$(this).css({'font-size': '10px'});
	});
	
/*Drupal.behaviors.auto_nodetitleFieldsetSummaries = {
  attach: function (context) {
    $('fieldset#edit-auto-nodetitle', context).drupalSetSummary(function (context) {

      // Retrieve the value of the selected radio button
      var ant = $("input[@name=#edit-auto-nodetitle-ant]:checked").val();

      if (ant==0) {
        return Drupal.t('Disabled')
      }
      else if (ant==1) {
        return Drupal.t('Automatic (hide title field)')
      }
      else if (ant==2) {
        return Drupal.t('Automatic (if title empty)')
      }
    });
  }
};*/

});
