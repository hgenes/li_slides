<pre><?php
$node = $data->_field_data['nid']['entity'];
$o = (object) Array(
  'body' => block_text_get_single_val($node->body));/*,
  'font-family' => block_text_get_single_val($node->field_font),
  'title-body-ratio' => block_text_get_single_val($node->field_title_body_ratio),
  'vertical-spacing' => block_text_get_single_val($node->field_vertical_spacing),
  'letter-spacing' => block_text_get_single_val($node->field_horizontal_spacing));*/
print_r($node);
//print (block_text_get_single_val($node->body));
?></pre>
