sizeRatio = 1;
jQuery(function ($) {
	$(".presentation_select_active").click( function() {
		presentationSelectActive($(this).val());
	});
	
	function presentationSelectActive(suffix) {
		$.ajax({
			type: 'POST',
		  url: '/casino/index.php?q=visual/block-text/select-active/' + suffix,
		  data: {},
		  cache: false,
		  success: function(response){
		    if(response = 'success') {
		    	//alert('woot');
				} else {
		    	//alert('wowwwot');
			  }
		  },
		  error: function(request, error){
		    alert(error);
		    alert("failed to update");
		  }
		});
	}
	
});
