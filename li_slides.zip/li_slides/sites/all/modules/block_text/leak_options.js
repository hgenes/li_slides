sizeRatio = 1;

jQuery(function ($) {
  $('.leak-option').hide();
	$('.leak-tag').click( function() {
	  $('.leak-tag').not(this).slideUp();
	  $('.leak-option').not('.' + $(this).attr('tid')).slideUp();
	  $('.' + $(this).attr('tid')).slideDown();
	});
	//$.cookie("test", 1);
	//alert($.cookie("current-leak"));
	$('.leak-option').click( function() {
	  $.cookie("current-leak", $(this).attr('nid'), { path: '/' });
	  $.cookie("changed", 1, { path: '/' });
	  $('.leak-tag').not(this).slideDown();
	  $('.leak-option').slideUp();
	});
	
/*Drupal.behaviors.auto_nodetitleFieldsetSummaries = {
  attach: function (context) {
    $('fieldset#edit-auto-nodetitle', context).drupalSetSummary(function (context) {

      // Retrieve the value of the selected radio button
      var ant = $("input[@name=#edit-auto-nodetitle-ant]:checked").val();

      if (ant==0) {
        return Drupal.t('Disabled')
      }
      else if (ant==1) {
        return Drupal.t('Automatic (hide title field)')
      }
      else if (ant==2) {
        return Drupal.t('Automatic (if title empty)')
      }
    });
  }
};*/

});
