sizeRatio = 1;
timerNextSlide = setTimeout( function() {}, 1000);
jQuery(function ($) {
	sizeRatio = $("#content").width() / 1024;

	$("#block_text_preview").height(720*sizeRatio);
	$("#block_text_preview").css('font-size', (100*sizeRatio).toString() + 'px');

	if (staticStream) {
 		$(".block_text").hide();
		staticStreamNext();
		$('body').keyup( function(e) {
			if(e.which == 78) {
				//alert(e.which);
				staticStreamNext();
			}
		});
	} else {
	 	setInterval(function() { checkNewText(); }, 5000);
	 	checkNewText();
 	}
 	
 	function staticStreamNext() {
 		clearTimeout(timerNextSlide);
 		$(".active_slide video").each( function() { 
	 		movie = document.getElementById($(this).attr('id'));
	 		movie.pause();
 		});
 		$(".active_slide").each( function() {
 			$(this).fadeOut();
 			$(this).removeClass("active_slide");
 			$(this).next(".block_text").addClass("active_slide");
 		});
 		if($(".active_slide").length == 0) {
	 		$(".block_text").first().addClass("active_slide");
 		}
 		$(".active_slide").fadeIn();
 		$(".active_slide video").each( function() { 
	 		movie = document.getElementById($(this).attr('id'));
	 		movie.currentTime = 0;
	 		movie.play();
 		});
 		$(".active_slide input.timer").each( function() { 
			timerNextSlide = setTimeout( function() { staticStreamNext(); }, $(this).val());
 		});
 		
 	}
 	
 	function checkNewText() {
		$.ajax({
			type: 'POST',
		  url: '/casino/index.php?q=visual/block-text/json/' + presid.toString(),
		  data: {},
		  cache: false,
		  success: function(response){
		    if(true) {
		    	replaceNID(response);
				} else {
			    alert(response);
			  }
		  },
		  error: function(request, error){
		    alert(error);
		    alert("failed");
		  }
		});
	}
 
	function replaceNID(node) {

		node = JSON.parse(node);
		//alert(node.nid);
		if ($("#block_text").html() != node.text) {
			//alert($("#block_text").html());
			//alert(node.text);
			$("#block_text").fadeOut(500);
			setTimeout( function() {
				$("#block_text").attr('class',node.variant);
				$("#block_text").html(node.text)/*.css('padding-top', (($("#block_text").height() - $("#block_text .inner").first().height()) /2).toString() + 'px' )*/.delay(100).fadeIn(3000);
			}, 700);
		} else {
			//alert('same ' + node.nid);
		}
	}
	
});
